using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.UI;

public class BallScript : MonoBehaviour {

    //declaring, and assigning our variables
    private Rigidbody2D ballRigidBody2D;
    public float ballLaunchSpeed = 0.5f;
    public SpriteRenderer paddleSprite;

    private bool wasBallLaunched = false;

    private AudioSource aSource;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI playText;

    public int playerScore = 0;

    // Start is called before the first frame update
    void Start() {

        //getting a reference to the attched components 
        ballRigidBody2D = gameObject.GetComponent<Rigidbody2D>();
        aSource = gameObject.GetComponent<AudioSource>();

        //updating our score text
        scoreText.text = "Score: " + playerScore.ToString();

    }

    // Update is called once per frame
    void Update() {

        //setting our score text
        scoreText.text = "Score: " + playerScore.ToString();

        //space to launch the ball, and we also check if it was launched
        if (Input.GetKeyDown(KeyCode.Space) && wasBallLaunched == false) {

            playText.gameObject.SetActive(false);
            ballRigidBody2D.AddForce(Vector2.up * ballLaunchSpeed, ForceMode2D.Impulse);
            wasBallLaunched = true;

        }

        //limiting ball movement speed
        if (ballRigidBody2D.velocity.magnitude >= 13.0f) {

            ballRigidBody2D.velocity = (ballRigidBody2D.velocity.normalized * 13.0f);

        } 
    }

    //
    //setting up our colllision statements here
    //

    void OnCollisionEnter2D( Collision2D collision ) {

        if( collision.gameObject.tag == "Brick" ) {

            //Debug.Log("Hit the Brick");

            aSource.Play();
            playerScore = playerScore + 1;

            //double check this line of code and experiment with it a little more
            //this code is not needed 
            //ballRigidBody2D.velocity += new Vector2(transform.position.x +  Random.Range(-1.68f, 1.68f), transform.position.y);

            collision.gameObject.SetActive(false);
            
        }

        if (collision.gameObject.tag == "Paddle") {

            //Debug.Log("Hit the paddle");
            aSource.Play();
            
            //was the ball launched? then when we hit the paddle we add a negative force to it
            //within a range 
            //not really sure how I came up with this, but I'm sure there is a better way.
            if (wasBallLaunched == true)
            {

                ballRigidBody2D.velocity -= new Vector2(transform.position.x + Random.Range(-1.80f, 1.80f), transform.position.y);
                
            }
        }


        //load a random scene if the ball falls below the paddle
        if (collision.gameObject.tag == "BottomWall") {

            //Debug.Log("Hit the paddle");
            int randomSceneLoad = Random.Range(0, 4);
            SceneManager.LoadScene(randomSceneLoad);

        }

    }

}
