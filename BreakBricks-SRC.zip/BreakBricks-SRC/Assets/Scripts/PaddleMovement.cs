using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleMovement : MonoBehaviour {

    //
    //the code below is test code, and isn't needed for the game
    //public Rigidbody2D rbody2D;
    //public int paddleThrustSpeed = 2;
    //

    //declare our variables
    public float paddleMovementSpeed = 1.0f;

    // Update is called once per frame
    void Update() {

        //limit the paddle to within the game window on the x position

        Vector2 localPosition = transform.position;
        localPosition.x = Mathf.Clamp(transform.position.x, -5.50f, 5.50f);
        transform.position = localPosition;

        /*if (Input.GetKeyDown(KeyCode.Space)) {

            rbody2D.AddForce(Vector2.up * paddleThrustSpeed, ForceMode2D.Impulse);

        }*/

        //movement code
        if (Input.GetKey(KeyCode.D)) {

            transform.Translate(Vector2.right * paddleMovementSpeed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.A)) {

            transform.Translate(Vector2.right * -paddleMovementSpeed * Time.deltaTime);
        }
    }
}
